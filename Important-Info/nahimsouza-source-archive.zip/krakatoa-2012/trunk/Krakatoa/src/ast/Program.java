package ast;

import java.util.*;

public class Program {

    public Program(ArrayList<ClassDec> classList) {
        this.classList = classList;
    }

    public void genC(PW pw) {
    }
    private ArrayList<ClassDec> classList;
}