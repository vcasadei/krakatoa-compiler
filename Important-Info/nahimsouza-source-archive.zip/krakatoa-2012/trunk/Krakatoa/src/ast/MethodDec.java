
package ast;

import lexer.Symbol;

public class MethodDec {
    // MethodDec := Qualifier ReturnType Id "(" [ FormalParamDec ]")" "{" StatementList "}" 
    
    private Symbol qualifier;
    private Type returnType;
    private String Id;
    private ParamList formalParamDec;
    private StatementList statList;

    // construtor
    public MethodDec(Symbol qualifier, Type returnType, String Id, ParamList formalParamDec, StatementList statList) {
        this.qualifier = qualifier;
        this.returnType = returnType;
        this.Id = Id;
        this.formalParamDec = formalParamDec;
        this.statList = statList;
    }
    
}
