
package ast;

import java.util.ArrayList;
import java.util.Iterator;

public class StatementList {
      
    public StatementList() {
        statList = new ArrayList<Statement>();
    }

    public void addElement(Statement s) {
        statList.add(s);
    }

    public Iterator<Statement> elements() {
        return statList.iterator();
    }

    public int getSize() {
        return statList.size();
    }
    
    private ArrayList<Statement> statList;

}
