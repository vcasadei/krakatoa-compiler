package ast;

public class MessageSendToSuper extends MessageSend {

    public Type getType() {
        return null;
    }

    public void genC(PW pw, boolean putParenthesis) {
    }
}