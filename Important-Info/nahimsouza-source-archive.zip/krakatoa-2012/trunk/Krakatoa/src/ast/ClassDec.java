package ast;

public class ClassDec extends Type {

    public ClassDec(String name) {
        super(name);
    }

    public String getCname() {
        return getName();
    }
    private String name;
    private ClassDec superclass;
    private InstanceVariableList instanceVariableList;
    private MethodList methodList;
    
    
    // private MethodList publicMethodList, privateMethodList;
    // metodos publicos get e set para obter e iniciar as variaveis acima,
    // entre outros metodos

    public InstanceVariableList getInstanceVariableList() {
        return instanceVariableList;
    }

    public void setInstanceVariableList(InstanceVariableList instanceVariableList) {
        this.instanceVariableList = instanceVariableList;
    }

    public ClassDec getSuperclass() {
        return superclass;
    }

    public void setSuperclass(ClassDec superclass) {
        this.superclass = superclass;
    }
}
