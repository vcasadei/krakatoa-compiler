/*****************************************************************************
 *                     Laborat�rio de Compiladores                           *
 *																			 *
 * Autor: Alexandre Braga Saldanha											 *
 * R.A.: 408484                                                              *
 ****************************************************************************/

package ast;

abstract public class Statement {

	abstract public void genC(PW pw);

}
