package ast;

public class TypeVoid extends Type {

	public TypeVoid() {
		super("void");
	}

	public String getCname() {
		return "void";
	}

	public String getKraname() {
		return "void";
	}

}