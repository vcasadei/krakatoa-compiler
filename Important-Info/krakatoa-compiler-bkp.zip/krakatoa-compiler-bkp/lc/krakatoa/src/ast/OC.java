package ast;

public class OC extends Expr {

	public OC(KraClass kraClass) {
		this.kraClass = kraClass;
	}

	@Override
	public void genC(PW pw, boolean putParenthesis) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void genKra(PW pw, boolean putParenthesis) {
		// TODO Auto-generated method stub
		
	}
	
	public Type getType() {
		return kraClass;
	}

	public void setCast(KraClass castClass) {
		this.castClass = castClass;
	}

	private KraClass kraClass;
	private KraClass castClass;
}
