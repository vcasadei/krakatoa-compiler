package ast;

abstract public class Statement {

	abstract public void genC(PW pw);

}
